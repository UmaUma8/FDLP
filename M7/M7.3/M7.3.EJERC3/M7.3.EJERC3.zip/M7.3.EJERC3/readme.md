# (M7.3) Exrcici 03

L’usuari ha d’introduir una frase i el programa ha de dir si la frase és un **palíndrom**.