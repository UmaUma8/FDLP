function showNumbers(){
    
    let pairs = []
    let count = 2

    for (; count <= 100; count+=2){
        console.log(count)
        
        pairs.push(count)
        
        pairs.sort((a, b) => b - a);
       

        document.getElementById("pairs").innerHTML = pairs;

    }
}