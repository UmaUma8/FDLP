let table = Number(prompt('TAULA DE MULTIPLICAR. Introdueix el número'));
let count = 0;

for (; count <= 10; count++) {
    console.log(count);

    document.write(table + " x " + count + " = " + (table * count) + "<br>");

}
